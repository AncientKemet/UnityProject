var searchData=
[
  ['isdirty',['isDirty',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___multi_mesh_combiner_1_1_combined_mesh.html#a99c5d3bb703fad944f49ec3d24f6b374',1,'DigitalOpus::MB::Core::MB2_MultiMeshCombiner::CombinedMesh']]]
];
