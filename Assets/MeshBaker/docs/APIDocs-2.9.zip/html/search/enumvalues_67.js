var searchData=
[
  ['generate_5fnew_5fuv2_5flayout',['generate_new_UV2_layout',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a7c6398a07657fe2d755d25429858086caf0e5280529f04e7f8c2244f35d15ff7d',1,'DigitalOpus::MB::Core']]]
];
