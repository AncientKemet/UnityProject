var searchData=
[
  ['ignore_5fuv2',['ignore_UV2',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a7c6398a07657fe2d755d25429858086ca1cb645e4e8ea47b147319ade082fdbde',1,'DigitalOpus::MB::Core']]],
  ['info',['info',['../namespace_digital_opus_1_1_m_b_1_1_core.html#ad2c4d102326041d70cf945d3434e7772acaf9b6b99962bf5c2264824231d7a40c',1,'DigitalOpus::MB::Core']]],
  ['iscompressed',['IsCompressed',['../interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___editor_methods_interface.html#a52f74be68ce50b929dbec78384427bea',1,'DigitalOpus::MB::Core::MB2_EditorMethodsInterface']]],
  ['isdirty',['isDirty',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___multi_mesh_combiner_1_1_combined_mesh.html#a99c5d3bb703fad944f49ec3d24f6b374',1,'DigitalOpus::MB::Core::MB2_MultiMeshCombiner::CombinedMesh']]],
  ['isempty',['isEmpty',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___multi_mesh_combiner_1_1_combined_mesh.html#a112e3a977464c012526bbe638ad8996e',1,'DigitalOpus::MB::Core::MB2_MultiMeshCombiner::CombinedMesh']]]
];
