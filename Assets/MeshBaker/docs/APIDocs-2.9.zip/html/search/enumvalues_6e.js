var searchData=
[
  ['none',['none',['../namespace_digital_opus_1_1_m_b_1_1_core.html#ad2c4d102326041d70cf945d3434e7772a334c4a4c42fdb79d7ebc3e73b517e6f8',1,'DigitalOpus::MB::Core']]]
];
