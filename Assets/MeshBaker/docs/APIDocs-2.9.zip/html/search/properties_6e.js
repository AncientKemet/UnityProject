var searchData=
[
  ['name',['name',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___mesh_combiner.html#a7352b7e6fdb6fde5cd77d0151f3afdc9',1,'DigitalOpus.MB.Core.MB2_MeshCombiner.name()'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___multi_mesh_combiner.html#a249cebf459ff96c6954f2f21a8010d18',1,'DigitalOpus.MB.Core.MB2_MultiMeshCombiner.name()']]]
];
